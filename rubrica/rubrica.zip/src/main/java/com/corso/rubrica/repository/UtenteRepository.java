package com.corso.rubrica.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.corso.rubrica.model.Utente;

public interface UtenteRepository extends JpaRepository<Utente, Integer>{
	List<Utente> findByNomeAndCognome(String nome, String cognome);
	
	@Query("select u from Utente u where i.nome= :nome")
	List<Utente> findByNome(String nome);
	
	List<Utente> findByCognome(String cognome);	

}
